import logging
import asyncio

from dataclasses import dataclass
from asyncio.exceptions import TimeoutError

from aiohttp import client_exceptions
from aiohttp.client import ClientSession

from .clients import Clients
from .devices import Devices
from .errors import (OmadaApiException, HttpErrorCode, InvalidURLError, SSLError, UnknownSite, raise_response_error, RequestError, RequestTimeout)
from .known_clients import KnownClients

LOGGER = logging.getLogger(__name__)

API_PATH = "/api/v2"
OPEN_API_PATH = "/openapi/v2"


@dataclass
class RFPlanningState:
    status: int
    schedule_enable: bool


class Controller:
    def __init__(
            self,
            url: str,
            username: str,
            password: str,
            req_timeout: int,
            websession: ClientSession,
            site: str = "Default",
            ssl_context=None,
    ):

        self.url = url
        self.site = site
        self.name = None
        self.version = None
        self.controller_id = None
        self._username = username
        self._password = password
        self._req_timeout = req_timeout
        self._session = websession
        self._ssl_context = ssl_context
        self._site_id = None
        self._token = None
        self.clients = Clients(self._client_request)
        self.devices = Devices(self._site_request)
        self.known_clients = KnownClients(self._site_request)
        self.ssids = set()
        self.rf_planning = None

    async def login(self) -> None:
        """Call to obtain login token, controller id, and site id."""

        # Update API information before doing anything. This also ensures we correctly recover from controller upgrades.
        await self._update_api_info()

        auth = {"username": self._username, "password": self._password}
        response = await self._controller_request("post", "/login", json=auth)

        self._token = response["token"]

        LOGGER.info("Login successful.")

        # Acquire site id for site name as required for versions 5+
        if self.version >= "5.0.0":
            await self._update_site_id()

    async def _update_api_info(self):
        """Obtain basic API information required to properly interact with different versions of the API."""

        response = await self._request("get", f"{self.url}/api/info")
        self.version = response["controllerVer"]
        self.clients.use_v6_openapi = self.version >= "6.0.0"
        if self.version >= "5.0.0":
            self.controller_id = response["omadacId"]

    @property
    def site_id(self) -> str:
        """Stable site identifier: the Omada 5+ site key, or the site name on v4."""
        return self._site_id or self.site

    async def _update_site_id(self):
        """Obtain site id for specified site name. Required in v5.0.0+"""

        response = await self._controller_request(
            "get",
            "/users/current",
            params=[("currentPage", "1"), ("currentPageSize", "10000")],
            private=True,
        )

        for site in response["privilege"]["sites"]:
            if site["name"] == self.site:
                self._site_id = site["key"]
                break

        if not self._site_id:
            raise UnknownSite(f"Unknown site '{self.site}'")

    async def update_status(self):
        """Update controller information."""

        response = await self._controller_request(
            "get", "/maintenance/controllerStatus", private=True
)
        self.name = response["name"]

        try:
            response = await self._site_request("get", "/rfPlanning")
            status_response = await self._site_request("get", "/rfPlanning/result")

            self.rf_planning = RFPlanningState(
                status=status_response.get("status", None),
                schedule_enable=response.get("scheduleEnable", None))
        except OmadaApiException as err:
            self.rf_planning = None
            LOGGER.warn(f"Unable to get rfPlanning status: {err}")

    async def update_ssids(self):
        """Retrieve the list of avaiable SSIDs within a site."""

        if self.version < "4.4.8":
            response = await self._site_request("get", "/setting/ssids")

            self.ssids.clear()

            for ssid in response["ssids"][0]["ssidList"]:
                self.ssids.add(ssid["ssidName"])

        else:
            response = await self._site_request("get", "/setting/wlans")

            self.ssids.clear()

            # The key of the id changed in v5
            wland_id_key = None
            if self.version >= "5.0.0":
                wland_id_key = "id"
            else:
                wland_id_key = "wlanId"

            for wlan in response["data"]:
                wlan_id = wlan[wland_id_key]
                ssid_response = await self._site_request(
                    "get", f"/setting/wlans/{wlan_id}/ssids"
                )

                for ssid in ssid_response["data"]:
                    self.ssids.add(ssid["name"])

    async def start_rf_planning(self):
        await self._site_request("POST", "/cmd/rfPlanning/optimization")

    async def set_rf_planning_enable(self, enabled: bool):
        await self._site_request("PUT", "/rfPlanning/schedule",
                                        json={"scheduleEnable": enabled})

    async def _site_request(self, method, end_point, params=None, json=None):
        """Perform a request specific to a site."""

        endpoint = None
        if self.version >= "5.0.0":
            endpoint = f"/sites/{self._site_id}{end_point}"
        else:
            endpoint = f"/sites/{self.site}{end_point}"

        return await self._controller_request(method, endpoint, params=params, json=json, private=True)

    async def _client_request(self, method, end_point, params=None, json=None):
        """Perform a client request using the v6 openapi path when required."""

        if self.version >= "6.0.0":
            return await self._openapi_site_request(method, end_point, params=params, json=json)

        return await self._site_request(method, end_point, params=params, json=json)

    async def _openapi_site_request(self, method, end_point, params=None, json=None):
        """Perform a site request against the openapi path using the current session."""

        endpoint = None
        if self.version >= "5.0.0":
            endpoint = f"/sites/{self._site_id}{end_point}"
        else:
            endpoint = f"/sites/{self.site}{end_point}"

        return await self._openapi_controller_request(method, endpoint, params=params, json=json)

    async def _openapi_controller_request(self, method, end_point, params=None, json=None):
        """Perform an openapi request using the existing authenticated session."""

        if not self.version:
            raise Exception(
                "Controller version has not been fetched. Please call update_status() first."
            )

        if self.version >= "5.0.0":
            url = f"{self.url}{OPEN_API_PATH}/{self.controller_id}{end_point}"
        else:
            url = f"{self.url}{OPEN_API_PATH}{end_point}"

        return await self._request(
            method,
            url,
            params=params,
            json=json,
            private=True,
            extra_headers={
                "X-Requested-With": "XMLHttpRequest",
                "Omada-Request-Source": "web-local",
            },
        )

    async def _controller_request(
            self, method, end_point, params=None, json=None, private=False
    ):
        """Perform a request specific to the controlller"""

        if not self.version:
            raise Exception(
                "Controller version has not been fetched. Please call update_status() first."
            )

        url = None
        if self.version >= "5.0.0":
            url = f"{self.url}/{self.controller_id}{API_PATH}{end_point}"
        else:
            url = f"{self.url}{API_PATH}{end_point}"

        return await self._request(
            method, url, params=params, json=json, private=private
        )

    async def _request(self, method, url, params=None, json=None, private=False, extra_headers=None):
        """Perform a request. Will automatically handle the login token if private is set to True."""

        headers = {}

        if private:
            if not self.version:
                raise Exception(
                    "Controller version has not been fetched. Please call update_status() first."
                )

            if self.version >= "5.0.0":
                headers["Csrf-Token"] = self._token
            else:
                if params is None:
                    params = []
                params.append(("token", self._token))

        if extra_headers:
            headers.update(extra_headers)

        LOGGER.debug("Requesting: %s - Params: %s - JSON: %s - Headers %s", url, params, json, headers)

        try:
            async with asyncio.timeout(self._req_timeout):
                async with self._session.request(
                        method,
                        url,
                        params=params,
                        headers=headers,
                        json=json,
                        ssl=self._ssl_context,
                ) as res:
                    LOGGER.debug("%s %s %s", res.status, res.content_type, res)

                    if res.status != 200:
                        if res.content_type == "application/json":
                            response = await res.json()
                            self._raiseOnResponseError(url, response)

                        LOGGER.warning(
                            f"Error connecting to {url}: API returned HTTP {res.status}."
                        )
                        raise HttpErrorCode(url=url, code=res.status)

                    if res.content_type == "application/json":
                        response = await res.json()

                        self._raiseOnResponseError(url, response)
                        if "result" in response:
                            return response["result"]
                        return response
                    else:
                        raise RequestError(url, "Received non-json response!")
        except TimeoutError:
            raise RequestTimeout(url)
        except client_exceptions.ClientConnectorCertificateError as err:
            raise SSLError(url, err)
        except client_exceptions.InvalidURL:
            raise InvalidURLError(url, "Invalid URL")
        except client_exceptions.ClientError as err:
            raise RequestError(url, err) from None

    def _raiseOnResponseError(self, url, response):
        if not isinstance(response, dict):
            return

        if "errorCode" in response and response["errorCode"] != 0:
            raise_response_error(url, response)
